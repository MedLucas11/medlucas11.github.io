import cv2
import numpy as np
import time
import json
import base64
import os
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from mtcnn import MTCNN
from keras_facenet import FaceNet 
from scipy.spatial.distance import euclidean
from pydantic import BaseModel

# Caminhos dos arquivos de banco de dados (Unificados)
EMBEDDINGS_FILE = "dados/embeddings.npy"
USERS_FILE = "dados/users.json"

class CadastroRequest(BaseModel):
    nome: str
    imagem_base64: str

app = FastAPI()

# 1. SOLUÇÃO DO ERRO 405 (CORS): Permite que o navegador envie dados sem ser bloqueado
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

try:
    dados_calibracao = np.load("dados/calibracao.npz")
    camera_matrix = dados_calibracao['mtx']
    dist_coeffs = dados_calibracao['dist']
    print("✅ Parâmetros de calibração da câmera carregados.")
except FileNotFoundError:
    camera_matrix = None
    dist_coeffs = None
    print("⚠️ Calibração não encontrada. O sistema rodará com as imagens brutas.")

print("Carregando modelos biométricos e banco de dados...")
detector = MTCNN()
embedder = FaceNet()

# Variáveis globais para a memória RAM
banco_matriz = []
banco_nomes = {}

def carregar_banco_de_dados():
    """Carrega os rostos do HD para a Memória. É chamada ao iniciar e após cada cadastro."""
    global banco_matriz, banco_nomes
    if os.path.exists(EMBEDDINGS_FILE) and os.path.exists(USERS_FILE):
        banco_matriz = np.load(EMBEDDINGS_FILE)
        with open(USERS_FILE, "r") as f:
            banco_nomes = json.load(f)
        print(f"Banco carregado: {len(banco_nomes)} usuários.")
    else:
        banco_matriz = np.array([])
        banco_nomes = {}
        print("Banco de dados vazio. Faça o primeiro cadastro.")

# Carrega a base ao ligar o servidor
carregar_banco_de_dados()

LIMIAR_ACEITACAO = 0.85 

@app.get("/")
async def index():
    with open("index.html", "r", encoding="utf-8") as f:
        return HTMLResponse(f.read())

# 2. SOLUÇÃO DO ERRO 404: Ensina o FastAPI a responder quando chamarem /index.html
@app.get("/index.html")
async def index_html():
    return FileResponse("index.html")

@app.get("/cadastro.html")
async def abrir_pagina_cadastro():
    return FileResponse("cadastro.html")

@app.get("/metricas.json")
async def get_metricas():
    # Caminho corrigido para evitar falhas se a pasta final não existir
    caminho = "dados/metricas.json" if os.path.exists("dados/metricas.json") else "metricas.json"
    if os.path.exists(caminho):
        with open(caminho, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

@app.post("/cadastrar")
async def cadastrar_rosto(req: CadastroRequest):
    try:
        encoded_data = req.imagem_base64.split(',')[1]
        nparr = np.frombuffer(base64.b64decode(encoded_data), np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        deteccoes = detector.detect_faces(img_rgb)
        deteccoes = [d for d in deteccoes if d['confidence'] >= 0.95]
        
        if len(deteccoes) == 0:
            return {"sucesso": False, "mensagem": "Nenhum rosto nítido detectado. Tente novamente."}
        if len(deteccoes) > 1:
            return {"sucesso": False, "mensagem": "Mais de um rosto detectado. Fique sozinho na câmera."}

        x, y, w, h = deteccoes[0]['box']
        x, y = max(0, x), max(0, y)
        rosto_recortado = img_rgb[y:y+h, x:x+w]
        rosto_redimensionado = cv2.resize(rosto_recortado, (160, 160))
        rosto_expandido = np.expand_dims(rosto_redimensionado, axis=0)
        
        novo_embedding = embedder.embeddings(rosto_expandido)[0]

        os.makedirs(os.path.dirname(EMBEDDINGS_FILE), exist_ok=True)

        # Atualiza as listas
        if os.path.exists(EMBEDDINGS_FILE) and os.path.exists(USERS_FILE):
            embeddings = np.load(EMBEDDINGS_FILE).tolist()
            with open(USERS_FILE, "r") as f:
                users = json.load(f)
        else:
            embeddings = []
            users = {}

        novo_id = str(len(users))
        embeddings.append(novo_embedding)
        users[novo_id] = req.nome

        # Salva no HD
        np.save(EMBEDDINGS_FILE, np.array(embeddings))
        with open(USERS_FILE, "w") as f:
            json.dump(users, f, indent=4)

        # 3. SOLUÇÃO DA AMNÉSIA: Atualiza a memória RAM imediatamente
        carregar_banco_de_dados()

        return {"sucesso": True, "mensagem": f"Usuário {req.nome} cadastrado com sucesso!"}

    except Exception as e:
        return {"sucesso": False, "mensagem": f"Erro interno: {str(e)}"}

@app.websocket("/ws/video")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    
    try:
        while True:
            data = await websocket.receive_text()
            encoded_data = data.split(',')[1]
            nparr = np.frombuffer(base64.b64decode(encoded_data), np.uint8)
            frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            # ==========================================
            # APLICAÇÃO DA CALIBRAÇÃO (NOVO)
            # ==========================================
            # Desentorta a imagem corrigindo as distorções da lente antes da IA
            if camera_matrix is not None and dist_coeffs is not None:
                frame = cv2.undistort(frame, camera_matrix, dist_coeffs, None, camera_matrix)
            # ==========================================

            
            start_time = time.time()
            img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            deteccoes = detector.detect_faces(img_rgb)
            
            resultado = {
                "nome": "Desconhecido",
                "reconhecido": False,
                "distancia": 0.0,
                "tempo_inferencia": 0,
                "rostos_encontrados": len(deteccoes)
            }
            
            if len(deteccoes) > 0:
                x, y, w, h = deteccoes[0]['box']
                x, y = max(0, x), max(0, y)
                rosto = img_rgb[y:y+h, x:x+w]
                
                if rosto.size > 0:
                    rosto = cv2.resize(rosto, (160, 160))
                    rosto_batch = np.expand_dims(rosto, axis=0)
                    
                    embedding_atual = embedder.embeddings(rosto_batch)[0]
                    
                    menor_distancia = float('inf')
                    nome_identificado = "Desconhecido"
                    
                    # Usa a matriz da memória RAM atualizada
                    if len(banco_matriz) > 0:
                        for i, embedding_salvo in enumerate(banco_matriz):
                            dist = euclidean(embedding_atual, embedding_salvo)
                            if dist < menor_distancia:
                                menor_distancia = dist
                                # Garante que vai achar o nome pelo índice (ID) no formato string
                                nome_candidato = banco_nomes.get(str(i), "Desconhecido")
                                
                        if menor_distancia < LIMIAR_ACEITACAO:
                            resultado["nome"] = nome_candidato
                            resultado["reconhecido"] = True
                        
                        resultado["distancia"] = round(float(menor_distancia), 3)
                    
            resultado["tempo_inferencia"] = round((time.time() - start_time) * 1000, 1)
            
            if resultado["reconhecido"]:
                confianca_perc = 100.0 - ((resultado["distancia"] / LIMIAR_ACEITACAO) * 25.0)
                resultado["confianca"] = round(max(70.0, min(100.0, confianca_perc)), 1)
            else:
                resultado["confianca"] = 0.0

            await websocket.send_json(resultado)
            
    except WebSocketDisconnect:
        pass