# Fechadura Inteligente - Sistema de Controle de Acesso Biométrico

Este projeto é um MVP (Minimum Viable Product) de uma Fechadura Eletrônica baseada em Inteligência Artificial. O sistema utiliza Visão Computacional para detecção facial e extração de biometria, simulando o destrancamento de uma porta em tempo real através de uma interface web interativa.

## ⚙️ Como Funciona

A arquitetura do projeto é dividida em três pilares principais:

1. **Frontend (Dashboard e Câmera):** Desenvolvido em HTML, CSS e JavaScript (Vanilla). Ele captura o feed da webcam e possui um algoritmo de "Detecção de Movimento" (comparação de pixels) que só envia os quadros para o servidor quando há alguém na frente da porta, economizando processamento.
2. **Comunicação:** Utiliza **WebSockets** para enviar as imagens em Base64 para o backend com baixíssima latência e receber o status de autorização no mesmo instante.
3. **Backend e IA (Python + FastAPI):** 
   - Recebe a imagem e utiliza a rede neural **MTCNN** para detectar onde está o rosto.
   - Recorta o rosto e o envia para o **FaceNet**, que extrai um vetor matemático de características (Embedding).
   - Calcula a **Distância Euclidiana** entre a pessoa na câmera e o banco de dados (`dados/embeddings.npy`).
   - Se a distância for menor que o Limiar de Aceitação (Threshold), o acesso é liberado.

## 🚀 Como Rodar o Projeto

### Pré-requisitos
Certifique-se de ter o Python 3.8+ instalado e de estar na pasta raiz do projeto. Instale todas as dependências necessárias executando:

```bash
pip install -r requirements.txt
```


### Inicializando o Servidor
1. No terminal, inicie o servidor FastAPI através do Uvicorn:

```bash
uvicorn server:app --reload
```

2. Abra o seu navegador e acesse:
   👉 **[http://127.0.0.1:8000](http://127.0.0.1:8000)**

### 👤 Fluxo de Uso
- **Ligar Sistema:** Clique no botão para ativar a câmera no Dashboard.
- **Cadastrar Rosto:** Vá até a página de cadastro, insira seu nome e tire uma foto para salvar sua biometria no arquivo JSON/Numpy.
- **Validação:** Volte para a página inicial. O sistema fará a leitura automaticamente quando você se aproximar e alterará o status do cadeado para "Acesso Liberado" ou "Acesso Negado".

## 🧪 Scripts de Avaliação (Para Artigo Científico)

O projeto acompanha scripts focados em validar a eficácia do modelo matemático, fundamentais para a documentação e métricas acadêmicas (F1-Score, Acurácia, Precisão, Recall):

- `preparar_teste_lfw.py` e `preparar_teste_fei.py`: Scripts para injetar datasets públicos (LFW e FEI Face Database) e criar cenários de estresse e ambientes cooperativos.
- `avaliar_modelo.py`: Roda a validação das pastas de teste, cruza os embeddings e descobre automaticamente qual é o **Limiar (Threshold) Matemático Ideal** da aplicação.
- `remover_usuario.py`: Script utilitário para limpar usuários específicos do banco de dados sem quebrar os índices vetoriais.

## 📂 Estrutura de Pastas

```text
/
├── server.py                 # Backend principal da API (FastAPI)
├── index.html                # Dashboard da fechadura inteligente
├── cadastro.html             # Página para registro de novos usuários
├── requirements.txt          # Lista de dependências do projeto
├── /dados                    # Banco de dados, calibração e diretório de datasets
│   ├── embeddings.npy        # Matriz vetorial com a biometria salva
│   ├── users.json            # Dicionário de IDs e Nomes
│   ├── metricas.json         # Resultados gerados pelos scripts de avaliação
│   ├── calibracao.npz        # Parâmetros intrínsecos da câmera (mtx e dist) para correção de lente
│   ├── /fotos_calibracao     # Imagens do tabuleiro de xadrez para cálculo de distorção
│   ├── /lfw-deepfunneled     # Dataset original LFW descompactado (Cenário de Estresse)
│   ├── /fei_face_database    # Dataset original FEI descompactado (Ambiente Controlado)
│   ├── /fotos_cadastro       # Imagens brutas capturadas no cadastro real de usuários
│   ├── /fotos_teste_fei      # Subdivisão organizada de imagens do FEI para validação em lote
│   └── /fotos_testes_lfw     # Subdivisão organizada de imagens do LFW para validação em lote
├── /scripts # (Opcional) Scripts de validação estatística, limpeza e calibração
```