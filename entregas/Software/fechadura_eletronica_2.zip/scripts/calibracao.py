import cv2
import numpy as np
import os
import glob

# Definições do tabuleiro de xadrez
CHECKERBOARD = (6,8)
criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)

objpoints = []
imgpoints = [] 

objp = np.zeros((1, CHECKERBOARD[0] * CHECKERBOARD[1], 3), np.float32)
objp[0,:,:2] = np.mgrid[0:CHECKERBOARD[0], 0:CHECKERBOARD[1]].T.reshape(-1, 2)
prev_img_shape = None

print("Iniciando calibração. Lendo imagens...")
images = glob.glob('dados/fotos_calibracao/*.jpg')

if not images:
    print("❌ Nenhuma imagem encontrada em 'dados/fotos_calibracao/'")
    exit()

for fname in images:
    img = cv2.imread(fname)
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    
    ret, corners = cv2.findChessboardCorners(gray, CHECKERBOARD, cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_FAST_CHECK + cv2.CALIB_CB_NORMALIZE_IMAGE)
    
    if ret == True:
        objpoints.append(objp)
        corners2 = cv2.cornerSubPix(gray, corners, (11,11),(-1,-1), criteria)
        imgpoints.append(corners2)

        img = cv2.drawChessboardCorners(img, CHECKERBOARD, corners2, ret)
    
    cv2.imshow('Calibracao', img)
    cv2.waitKey(500) # Exibe cada foto por meio segundo e avança sozinho

cv2.destroyAllWindows()

print("Calculando parâmetros (isso pode levar alguns segundos)...")
ret, mtx, dist, rvecs, tvecs = cv2.calibrateCamera(objpoints, imgpoints, gray.shape[::-1], None, None)

print("\nMatriz da Câmera:\n", mtx)
print("\nCoeficientes de Distorção:\n", dist)

# ==========================================
# SALVANDO OS PARÂMETROS PARA O FLUXO PRINCIPAL
# ==========================================
os.makedirs("dados", exist_ok=True)
caminho_salvamento = "dados/calibracao.npz"

np.savez(caminho_salvamento, mtx=mtx, dist=dist)

print(f"\n✅ Sucesso! Parâmetros de calibração salvos em: {caminho_salvamento}")