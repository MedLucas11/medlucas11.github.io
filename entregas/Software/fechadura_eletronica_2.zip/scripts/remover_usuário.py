import json
import numpy as np
import os

EMBEDDINGS_FILE = "dados/embeddings.npy"
USERS_FILE = "dados/users.json"

NOME_PARA_REMOVER = "Lucas Medeiros" 

print(f"Procurando por '{NOME_PARA_REMOVER}' no banco de dados...")

# 1. Carrega os arquivos
if os.path.exists(EMBEDDINGS_FILE) and os.path.exists(USERS_FILE):
    banco_matriz = np.load(EMBEDDINGS_FILE).tolist()
    with open(USERS_FILE, "r") as f:
        banco_nomes = json.load(f)
else:
    print("Erro: Banco de dados não encontrado.")
    exit()

# 2. Encontra o ID do usuário
id_para_remover = None
for key, name in banco_nomes.items():
    if name.lower() == NOME_PARA_REMOVER.lower():
        id_para_remover = key
        break

if id_para_remover is not None:
    idx = int(id_para_remover)
    nome_removido = banco_nomes[id_para_remover]
    
    # 3. Remove a assinatura matemática (embedding)
    banco_matriz.pop(idx)
    
    # 4. Reconstrói o dicionário para que os IDs continuem sequenciais (0, 1, 2...)
    novo_banco_nomes = {}
    valores_restantes = [nome for k, nome in banco_nomes.items() if k != id_para_remover]
    
    for i, nome in enumerate(valores_restantes):
        novo_banco_nomes[str(i)] = nome
        
    # 5. Salva as atualizações no HD
    np.save(EMBEDDINGS_FILE, np.array(banco_matriz))
    with open(USERS_FILE, "w") as f:
        json.dump(novo_banco_nomes, f, indent=4)
        
    print(f"✅ Sucesso: O usuário '{nome_removido}' e sua biometria foram apagados!")
    print(f"Total de usuários restantes no sistema: {len(novo_banco_nomes)}")
else:
    print(f"❌ Usuário '{NOME_PARA_REMOVER}' não encontrado. Verifique como o nome está escrito no users.json.")