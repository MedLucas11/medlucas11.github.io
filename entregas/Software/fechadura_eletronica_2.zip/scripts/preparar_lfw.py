import os
import shutil
import json
import numpy as np
import cv2
import random
from mtcnn import MTCNN
from keras_facenet import FaceNet

print("Carregando modelos IA para automação do cadastro...")
detector = MTCNN()
embedder = FaceNet()

# ==========================================
# CONFIGURAÇÕES
# ==========================================
CAMINHO_LFW_ORIGINAL = "dados/lfw-deepfunneled"
PASTA_TESTE = "dados/fotos_teste"
EMBEDDINGS_FILE = "dados/embeddings.npy"
USERS_FILE = "dados/users.json"

NUM_CELEBRIDADES = 20
MIN_FOTOS_POR_CELEBRIDADE = 15
NUM_DESCONHECIDOS = 200

# ==========================================
# 1. CARREGA O BANCO DE DADOS ATUAL
# ==========================================
os.makedirs("dados", exist_ok=True)
if os.path.exists(EMBEDDINGS_FILE) and os.path.exists(USERS_FILE):
    banco_matriz = np.load(EMBEDDINGS_FILE).tolist()
    with open(USERS_FILE, "r") as f:
        banco_nomes = json.load(f)
else:
    banco_matriz = []
    banco_nomes = {}

# ==========================================
# 2. MAPEIA AS PESSOAS NO LFW
# ==========================================
todas_pessoas = [p for p in os.listdir(CAMINHO_LFW_ORIGINAL) if os.path.isdir(os.path.join(CAMINHO_LFW_ORIGINAL, p))]

pessoas_com_muitas_fotos = []
for p in todas_pessoas:
    fotos = [f for f in os.listdir(os.path.join(CAMINHO_LFW_ORIGINAL, p)) if f.lower().endswith(('.jpg', '.png'))]
    if len(fotos) >= MIN_FOTOS_POR_CELEBRIDADE:
        pessoas_com_muitas_fotos.append((p, fotos))

# Seleciona as 20 primeiras que cumprem o requisito
celebridades_autorizadas = pessoas_com_muitas_fotos[:NUM_CELEBRIDADES]
nomes_autorizados = [c[0] for c in celebridades_autorizadas]

# ==========================================
# 3. CADASTRA E PREPARA AS PASTAS DAS CELEBRIDADES
# ==========================================
print(f"\nIniciando cadastro automático de {NUM_CELEBRIDADES} celebridades...")

for nome_pessoa, fotos in celebridades_autorizadas:
    pasta_destino = os.path.join(PASTA_TESTE, nome_pessoa)
    os.makedirs(pasta_destino, exist_ok=True)
    
    cadastrou = False
    
    for i, nome_foto in enumerate(fotos):
        caminho_origem = os.path.join(CAMINHO_LFW_ORIGINAL, nome_pessoa, nome_foto)
        
        # Se ainda não cadastrou essa pessoa, usa a foto para extrair a biometria
        if not cadastrou:
            img = cv2.imread(caminho_origem)
            if img is None: continue
                
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            deteccoes = detector.detect_faces(img_rgb)
            
            # Só cadastra se o MTCNN tiver 95% de certeza que é um rosto claro
            deteccoes = [d for d in deteccoes if d['confidence'] >= 0.95]
            
            if len(deteccoes) == 1:
                x, y, w, h = deteccoes[0]['box']
                x, y = max(0, x), max(0, y)
                rosto = img_rgb[y:y+h, x:x+w]
                
                rosto = cv2.resize(rosto, (160, 160))
                rosto_batch = np.expand_dims(rosto, axis=0)
                embedding = embedder.embeddings(rosto_batch)[0]
                
                # Adiciona ao banco de dados RAM
                novo_id = str(len(banco_nomes))
                banco_nomes[novo_id] = nome_pessoa.replace("_", " ") # Tira os underlines do LFW
                banco_matriz.append(embedding)
                
                cadastrou = True
                print(f" [+] {nome_pessoa.replace('_', ' ')} cadastrado(a) com sucesso.")
            else:
                # Se a primeira foto for ruim, joga pra pasta de teste e tenta a próxima
                shutil.copy(caminho_origem, os.path.join(pasta_destino, nome_foto))
        else:
            # Já cadastrou? O resto das fotos vai tudo para a pasta de teste
            shutil.copy(caminho_origem, os.path.join(pasta_destino, nome_foto))

# Salva o novo banco de dados no HD
np.save(EMBEDDINGS_FILE, np.array(banco_matriz))
with open(USERS_FILE, "w") as f:
    json.dump(banco_nomes, f, indent=4)
print("\n✅ Banco de dados biométrico (embeddings.npy e users.json) atualizado!")

# ==========================================
# 4. PREPARA A PASTA DE DESCONHECIDOS (FALSOS POSITIVOS)
# ==========================================
print(f"\nSeparando {NUM_DESCONHECIDOS} fotos de invasores (Desconhecidos)...")
pasta_desconhecidos = os.path.join(PASTA_TESTE, "Desconhecidos")
os.makedirs(pasta_desconhecidos, exist_ok=True)

# Pega todo mundo que NÃO está nas 20 celebridades escolhidas
pessoas_nao_autorizadas = [p for p in todas_pessoas if p not in nomes_autorizados]

# Sorteia 200 pastas diferentes de desconhecidos para pegar 1 foto de cada
random.shuffle(pessoas_nao_autorizadas)
invasores_selecionados = pessoas_nao_autorizadas[:NUM_DESCONHECIDOS]

contador_invasores = 0
for pessoa in invasores_selecionados:
    fotos = [f for f in os.listdir(os.path.join(CAMINHO_LFW_ORIGINAL, pessoa)) if f.lower().endswith(('.jpg', '.png'))]
    if len(fotos) > 0:
        caminho_origem = os.path.join(CAMINHO_LFW_ORIGINAL, pessoa, fotos[0])
        # Renomeia a foto pra não dar conflito (ex: Invasor_John_Doe_0001.jpg)
        novo_nome = f"Invasor_{pessoa}_{fotos[0]}"
        shutil.copy(caminho_origem, os.path.join(pasta_desconhecidos, novo_nome))
        contador_invasores += 1

print(f"✅ {contador_invasores} fotos de desconhecidos copiadas para teste.")
print("\n🚀 Automação concluída! Você já pode rodar o script de avaliação (avaliar_modelo.py).")