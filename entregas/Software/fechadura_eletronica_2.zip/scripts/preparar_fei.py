import os
import shutil
import json
import numpy as np
import cv2
import random
from mtcnn import MTCNN
from keras_facenet import FaceNet

print("Carregando modelos IA para automação do FEI Database...")
detector = MTCNN()
embedder = FaceNet()

# ==========================================
# CONFIGURAÇÕES 
# ==========================================
CAMINHO_FEI_ORIGINAL = "dados/fei_face_database"
PASTA_TESTE = "dados/fotos_teste_fei"
EMBEDDINGS_FILE = "dados/embeddings.npy"
USERS_FILE = "dados/users.json"

# Limita o número de pessoas cadastradas para o teste não demorar muito 
# (O FEI tem 200 pessoas. Vamos cadastrar 50 para ter um número robusto).
NUM_PESSOAS_CADASTRO = 50 

# Listas para geração de nomes fictícios
nomes_br = ["Ana", "Bruno", "Carlos", "Daniela", "Eduardo", "Fernanda", "Gabriel", "Helena", "Igor", "Julia", 
            "Leonardo", "Mariana", "Nicolas", "Olivia", "Pedro", "Quintino", "Rafael", "Sofia", "Tiago", "Yasmin"]
sobrenomes_br = ["Silva", "Santos", "Oliveira", "Souza", "Rodrigues", "Ferreira", "Alves", "Pereira", "Lima", "Gomes",
                 "Costa", "Ribeiro", "Martins", "Carvalho", "Almeida", "Lopes", "Soares", "Fernandes", "Vieira"]

# ==========================================
# 1. CARREGA O BANCO DE DADOS ATUAL
# ==========================================
os.makedirs("dados", exist_ok=True)
if os.path.exists(EMBEDDINGS_FILE) and os.path.exists(USERS_FILE):
    banco_matriz = np.load(EMBEDDINGS_FILE).tolist()
    with open(USERS_FILE, "r") as f:
        banco_nomes = json.load(f)
else:
    banco_matriz = []
    banco_nomes = {}

# ==========================================
# 2. AGRUPA AS FOTOS POR ID DA PESSOA
# ==========================================
print("\nLendo arquivos e agrupando por ID...")
arquivos = [f for f in os.listdir(CAMINHO_FEI_ORIGINAL) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]

pessoas_agrupadas = {}
for arquivo in arquivos:
    # Quebra o nome "1-01.jpg" no traço e pega o primeiro elemento ("1")
    partes = arquivo.split('-')
    if len(partes) >= 2:
        id_pessoa = partes[0]
        if id_pessoa not in pessoas_agrupadas:
            pessoas_agrupadas[id_pessoa] = []
        pessoas_agrupadas[id_pessoa].append(arquivo)

# ==========================================
# 3. SEPARA AUTORIZADOS E DESCONHECIDOS
# ==========================================
ids_disponiveis = list(pessoas_agrupadas.keys())
random.shuffle(ids_disponiveis)

ids_autorizados = ids_disponiveis[:NUM_PESSOAS_CADASTRO]
ids_desconhecidos = ids_disponiveis[NUM_PESSOAS_CADASTRO:]

nomes_gerados_unicos = set()

def gerar_nome_unico():
    while True:
        nome = f"{random.choice(nomes_br)} {random.choice(sobrenomes_br)}"
        if nome not in nomes_gerados_unicos:
            nomes_gerados_unicos.add(nome)
            return nome

print(f"\nIniciando cadastro automático de {len(ids_autorizados)} pessoas no padrão cooperativo...")

# ==========================================
# 4. CADASTRA AS PESSOAS AUTORIZADAS
# ==========================================
for id_pessoa in ids_autorizados:
    fotos = pessoas_agrupadas[id_pessoa]
    # Pega a foto -01 (que costuma ser a mais frontal no FEI) para cadastro
    fotos = sorted(fotos) 
    
    nome_ficticio = gerar_nome_unico()
    pasta_destino = os.path.join(PASTA_TESTE, nome_ficticio)
    os.makedirs(pasta_destino, exist_ok=True)
    
    cadastrou = False
    
    for nome_foto in fotos:
        caminho_origem = os.path.join(CAMINHO_FEI_ORIGINAL, nome_foto)
        
        if not cadastrou:
            img = cv2.imread(caminho_origem)
            if img is None: continue
                
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            deteccoes = detector.detect_faces(img_rgb)
            deteccoes = [d for d in deteccoes if d['confidence'] >= 0.95]
            
            if len(deteccoes) == 1:
                x, y, w, h = deteccoes[0]['box']
                x, y = max(0, x), max(0, y)
                rosto = img_rgb[y:y+h, x:x+w]
                
                rosto = cv2.resize(rosto, (160, 160))
                rosto_batch = np.expand_dims(rosto, axis=0)
                embedding = embedder.embeddings(rosto_batch)[0]
                
                novo_id = str(len(banco_nomes))
                banco_nomes[novo_id] = nome_ficticio
                banco_matriz.append(embedding)
                
                cadastrou = True
                print(f" [+] Cadastro FEI: {nome_ficticio} (ID original: {id_pessoa})")
            else:
                shutil.copy(caminho_origem, os.path.join(pasta_destino, nome_foto))
        else:
            # As outras 9 fotos da pessoa vão para a pasta de teste
            shutil.copy(caminho_origem, os.path.join(pasta_destino, nome_foto))

# Salva o banco de dados com os novos rostos
np.save(EMBEDDINGS_FILE, np.array(banco_matriz))
with open(USERS_FILE, "w") as f:
    json.dump(banco_nomes, f, indent=4)

# ==========================================
# 5. PREPARA A PASTA DE INVASORES (FALSOS POSITIVOS)
# ==========================================
print(f"\nSeparando invasores a partir dos IDs restantes...")
pasta_desconhecidos = os.path.join(PASTA_TESTE, "Desconhecidos")
os.makedirs(pasta_desconhecidos, exist_ok=True)

contador_invasores = 0
for id_pessoa in ids_desconhecidos:
    fotos = pessoas_agrupadas[id_pessoa]
    # Pega apenas as 2 primeiras fotos do invasor para não encher muito
    for nome_foto in fotos[:2]:
        caminho_origem = os.path.join(CAMINHO_FEI_ORIGINAL, nome_foto)
        novo_nome = f"Invasor_FEI_{id_pessoa}_{nome_foto}"
        shutil.copy(caminho_origem, os.path.join(pasta_desconhecidos, novo_nome))
        contador_invasores += 1

print(f"✅ {contador_invasores} fotos de desconhecidos controladas copiadas para teste.")
print("\n🚀 Automação concluída! Dataset cooperativo pronto na pasta 'dados/fotos_teste_fei'.")