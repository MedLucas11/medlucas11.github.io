import os
import json
import numpy as np
import cv2
from mtcnn import MTCNN
from keras_facenet import FaceNet
from scipy.spatial.distance import euclidean
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

print("Inicializando pipeline de avaliação...")
detector = MTCNN()
embedder = FaceNet()

# CAMINHOS CORRIGIDOS PARA A PASTA 'dados'
try:
    banco_matriz = np.load("dados/embeddings.npy")
    with open("dados/users.json", "r") as f:
        banco_nomes = json.load(f)
except FileNotFoundError:
    print("Erro: Rode o cadastrar pela interface web primeiro para gerar o banco de dados.")
    exit()

LIMIAR_ACEITACAO = 0.85
PASTA_TESTE = "dados/fotos_teste_fei"

y_true = [] # O que a pessoa REALMENTE é (1 = Autorizado, 0 = Desconhecido)
distancias_minimas = [] # A distância bruta que o modelo calculou
y_pred = [] 

print(f"\nIniciando varredura na pasta: {PASTA_TESTE}")

for pasta_pessoa in os.listdir(PASTA_TESTE):
    caminho_pasta = os.path.join(PASTA_TESTE, pasta_pessoa)
    if not os.path.isdir(caminho_pasta): 
        continue

    # CORREÇÃO DA REGRA LÓGICA: Procura nos valores do dicionário, e não nas chaves
    nomes_cadastrados = [nome.title() for nome in banco_nomes.values()]
    nome_pasta_limpo = pasta_pessoa.replace("_", " ").title()
    
    eh_autorizado_real = 1 if nome_pasta_limpo in nomes_cadastrados else 0

    fotos = [f for f in os.listdir(caminho_pasta) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    print(f"Avaliando {len(fotos)} fotos da classe verdadeira: {pasta_pessoa} (Label: {eh_autorizado_real})")

    for arquivo in fotos:
        caminho_img = os.path.join(caminho_pasta, arquivo)
        img = cv2.imread(caminho_img)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        deteccoes = detector.detect_faces(img_rgb)
        
        # Só consideramos deteccoes com alta confiança para não poluir o teste com falsos rostos
        deteccoes = [d for d in deteccoes if d['confidence'] >= 0.95]
        
        if len(deteccoes) == 0:
            print(f"  [!] Rosto não detectado pelo MTCNN em: {arquivo}. Ignorando.")
            continue
            
        x, y, w, h = deteccoes[0]['box']
        x, y = max(0, x), max(0, y)
        rosto = img_rgb[y:y+h, x:x+w]
        
        if rosto.size == 0: 
            continue
            
        rosto = cv2.resize(rosto, (160, 160))
        rosto_batch = np.expand_dims(rosto, axis=0)
        
        embedding_atual = embedder.embeddings(rosto_batch)[0]
        
        menor_distancia = float('inf')
        for embedding_salvo in banco_matriz:
            dist = euclidean(embedding_atual, embedding_salvo)
            if dist < menor_distancia:
                menor_distancia = dist
        
        eh_autorizado_pred = 1 if menor_distancia < LIMIAR_ACEITACAO else 0
        
        # 4. Apenas salva a distância, não toma a decisão ainda
        y_true.append(eh_autorizado_real)
        distancias_minimas.append(menor_distancia)
        y_pred.append(eh_autorizado_pred)

# ==========================================
# BUSCA DO LIMIAR IDEAL E MÉTRICAS
# ==========================================
print("\nBuscando o limiar (Threshold) matemático ideal...")

melhor_limiar = 0
melhor_f1 = -1 
melhores_metricas = {}

limiares_para_testar = np.arange(0.5, 1.5, 0.01)

for limiar_teste in limiares_para_testar:
    y_pred_simulado = [1 if d < limiar_teste else 0 for d in distancias_minimas]
    
    f1 = f1_score(y_true, y_pred_simulado, zero_division=0)
    
    if f1 > melhor_f1:
        melhor_f1 = f1
        melhor_limiar = limiar_teste
        
        melhores_metricas['acuracia'] = accuracy_score(y_true, y_pred_simulado)
        melhores_metricas['precisao'] = precision_score(y_true, y_pred_simulado, zero_division=0)
        melhores_metricas['recall'] = recall_score(y_true, y_pred_simulado, zero_division=0)
        
        # <-- MUDANÇA 2: Adiciona o labels=[0, 1] para forçar a matriz a sempre ter 4 campos (2x2)
        melhores_metricas['matriz'] = confusion_matrix(y_true, y_pred_simulado, labels=[0, 1]).ravel()

# Extrai a matriz vencedora com segurança
tn, fp, fn, tp = melhores_metricas['matriz']

metricas_finais = {
    "acuracia": round(melhores_metricas['acuracia'] * 100, 1),
    "precisao": round(melhores_metricas['precisao'] * 100, 1),
    "recall": round(melhores_metricas['recall'] * 100, 1),
    "f1_score": round(melhor_f1 * 100, 1) if melhor_f1 > 0 else 0.0
}

# Salva para o Frontend ler
with open("dados/metricas.json", "w", encoding="utf-8") as f:
    json.dump(metricas_finais, f, indent=4)

print("\n" + "="*45)
print("RESULTADOS DA AVALIAÇÃO OFFLINE")
print("="*45)
print(f"Limiar (Threshold) Ideal Encontrado: {melhor_limiar:.2f}")
print("="*45)
print(f"Total de imagens validadas: {len(y_true)}")
print(f"Verdadeiros Positivos (Abriu certo): {tp}")
print(f"Verdadeiros Negativos (Barrou certo): {tn}")
print(f"Falsos Positivos (Abriu pro invasor): {fp}  <-- Risco de Segurança")
print(f"Falsos Negativos (Barrou o dono): {fn}      <-- Risco de Experiência")
print("-" * 45)
print(f"Acurácia: {metricas_finais['acuracia']}%")
print(f"Precisão: {metricas_finais['precisao']}%")
print(f"Recall:   {metricas_finais['recall']}%")
print(f"F1-Score: {metricas_finais['f1_score']}%")
print("="*45)